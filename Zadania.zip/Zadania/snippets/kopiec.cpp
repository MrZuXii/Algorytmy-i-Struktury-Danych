#include <iostream>

using std::cout;
using std::swap;

int size = 0;
int *kopiec;

int getLeft(int i) {
  if ((2 * i + 1) < size)
    return (2 * i) + 1;
  return -1;
};

int getRight(int i) {
  if (2 * i + 2 < size)
    return (2 * i) + 2;
  return -1;
};

int getParent(int i) {
  if (i == 0)
    return -1;
  else
    return (i - 1) / 2;
};

// przywraca własność kopca metodą wynurzania
void bottomUp(int i) {
  if (i > 0) {
    int p = getParent(i);
    if (kopiec[i] > kopiec[p]) {
      swap(kopiec[i], kopiec[p]);
      bottomUp(p);
    }
  }
};

// przywraca własność kopca metodą zatapiania
void topDown(int i) {
  int left = getLeft(i);
  int right = getRight(i);

  int greatest = i;

  if (left != -1 && kopiec[left] > kopiec[i])
    greatest = left;
  if (right != -1 && kopiec[right] > kopiec[greatest])
    greatest = right;

  if (greatest != i) {
    swap(kopiec[i], kopiec[greatest]);
    topDown(greatest);
  }
};

// wstawia element z wartością x (tutaj wartość jest jednocześnie priorytetem)
void insert(int x) {
  if (full()) {
    cout << "Error: Kopiec pełny";
    return;
  }
  kopiec[size] = x;
  bottomUp(size);
  size++;
};

// usuwa element z "maksymalną" wartością priorytetu
void deleteP() {
  if (empty()) {
    cout << "Error: Kopiec pusty";
    return;
  }
  size--;
  swap(kopiec[0], kopiec[size]);
  topDown(0);
};

// usuwa element na pozycji i
void del(int i) {
  if (empty()) {
    cout << "Error: Kopiec pusty";
    return;
  }
  size--;
  swap(kopiec[i], kopiec[size]);
  topDown(i);
  bottomUp(i);
};