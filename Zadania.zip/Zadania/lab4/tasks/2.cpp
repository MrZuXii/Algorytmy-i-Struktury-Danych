#include <iostream>

using namespace std;

// Zadanie 1:

// Dla n losowo wygenerowanych liczb naturalnych, przechowywanych w tablicy S,
// proszę zaimplementować proste algorytmy sortowania. Algorytmy należy
// zaimplementować w postaci oddzielnych funkcji. Proszę przetestować poprawność
// ich działania według podanego w szablonie schematu.

// Zadanie 2:

// Do programu z zdania 1 proszę dodać kod implementujący eksperymentalne
// porównanie algorytmów z zadania 1, uwzględniając czas ich działania.

// Wykonanie eksperymentu wymaga:

// wybrania odpowiednio dużego rozmiaru tablicy
// generację losowych danych (oraz utworzenia ich kopii)
// sortowanie danych przy użyciu algorytmów z zadania 1 i zmierzenia i
// wyświetlenia czasu trwania sortowania dla każdego z nich Pomiar czasu:

//     clock_t start = clock();
//     //wywołanie funkcji
//     clock_t end = clock();
//     double result_time = (double) (end - start) /CLOCKS_PER_SEC;

// Pomiar czasu wymaga dołączenia bibliotek cstdlib i ctime.

// Zadanie 3:
// Do programu z zadania 2 proszę dodać i zaimplementować algorytm sortowania
// szybkiego i/lub sortowania przez scalanie, przetestować go według schematu
// dla zadania 1 oraz dodać do porównania z zadania 2.

// Szablon rozwiązania:

// //Zadanie 3
// void quickSort(int* S, int left, int right){
// }

// void mergeSort(int* S, int left, int right){
// }

// Zadanie 4:

// Do programu z zadania 3 proszę dodać i zaimplementować algorytm sortowania
// przez zliczanie, przetestować go według schematu dla zadania 1 oraz dodać do
// porównania z zadania 3.

// Szablon rozwiązania:

// //Zadanie 4
// void cntSort(int* S, int n, int k){   //k zakres liczb <0 - k)
// }

// wyświetla dane
void print(int *S, int n) {}

// generuje losowe dane
void init(int *S, int n) {}

void selectionSort(int *S, int n) {}

void insertionSort(int *S, int n) {}

void bubbleSort(int *S, int n) {}

void quickSort(int *S, int left, int right) {}

void mergeSort(int *S, int left, int right) {}

void cntSort(int *S, int n, int k) {}

int main() {
  int n = 20; // przykładowy rozmiar
  int *S = new int[n];
  delete[] S;
  return 0;
}