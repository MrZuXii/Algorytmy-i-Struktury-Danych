#include <iostream>
#include <limits>
using namespace std;

// Dla grafu ważonego (skierowanego lub nieskierowanego) reprezentowanego w
// postaci macierzy sąsiedztwa proszę zaimplementować algorytm Dijkstry
// znajdywania najkrótszej ścieżki z wybranego węzła s do pozostałych węzłów.
// Algorytm powinien zwracać, dla każdego węzła jego odległość od s oraz jego
// poprzednika na ścieżce od s. Proszę przetestować poprawność algorytmu dla
// różnych węzłów źródłowych.

// Zadanie 2:

// Do klasy z zadania 1 proszę dodać i przetestować metodę void
// shortestPath(int s, int t, int* parent) wyświetlającą węzły należące do
// najkrótszej ścieżki od węzła s do węzła t (na potrzeby testowania należy
// ją wywołać na końcu, w metodzie Dijkstra).

// Zadanie 3:

// Do programu z zadania 3 proszę dodać i przetestować algorytm
// Warshalla-Floyda. W wyniku należy wyświetlić długości najkrótszych ścieżek
// pomiędzy wszystkimi parami węzłów.
// void Warshall-Floyd();

struct weightedEdge {
  int s;
  int t;
  double w; // waga krawędzi
};

class WeightedGraph {
private:
  double **adjWeightMatrix;
  int n; // liczba węzłów
  bool directed;

public:
  // tworzy graf w oparciu o podaną listę krawędzi z wagami
  WeightedGraph(int n, int m, weightedEdge edges[], bool directed)
      : n(n), directed(directed) {
    adjWeightMatrix = new double *[n];

    for (int i = 0; i < n; i++) {
      adjWeightMatrix[i] = new double[n];
      for (int j = 0; j < n; j++) {
        adjWeightMatrix[i][j] =
            (i == j) ? 0 : numeric_limits<double>::infinity();
      }
    }

    for (int i = 0; i < m; i++) {
      int s = edges[i].s;
      int t = edges[i].t;
      int w = edges[i].w;

      adjWeightMatrix[s][t] = w;
      if (!directed) {
        adjWeightMatrix[t][s] = w;
      }
    }
  };

  WeightedGraph(int n, int m, bool directed); // tworzy losowy graf

  int find(double *d, bool *S, int n) {
    int minIndex = -1;
    double minValue = numeric_limits<double>::infinity();

    for (int i = 0; i < n; i++) {
      if (!S[i] && d[i] < minValue) {
        minValue = d[i];
        minIndex = i;
      }
    }

    return minIndex;
  }

  void dijkstra(int s) {
    bool *S = new bool[n];
    double *d = new double[n];
    int *parent = new int[n];

    for (int i = 0; i < n; i++) {
      d[i] = numeric_limits<double>::infinity();
      S[i] = false;
      parent[i] = -1;
    }
    d[s] = 0;

    for (int i = 0; i < n; i++) {
      int u = find(d, S, n);
      S[u] = true;

      for (int j = 0; j < n; j++) {
        if (d[j] > d[u] + adjWeightMatrix[u][j]) {
          d[j] = d[u] + adjWeightMatrix[u][j];
          parent[j] = u;
        }
      }
    }

    cout << "Odległości od wierzchołka " << s << ":\n";
    for (int i = 0; i < n; i++) {
      if (d[i] == numeric_limits<double>::infinity()) {
        cout << "Do wierzchołka " << i << ": brak połączenia\n";
      } else {
        cout << "Do wierzchołka " << i << ": " << d[i];
        if (parent[i] != -1) {
          cout << " (poprzednik: " << parent[i] << ")";
        }
        cout << endl;
      }
    }

    int t = 3; // Węzeł docelowy (zmień według potrzeb)
    shortestPath(s, t, parent);

    delete[] S;
    delete[] d;
    delete[] parent;
  }

  void shortestPath(int s, int t, int *parent) {
    // Sprawdzenie, czy istnieje ścieżka do węzła t
    if (parent[t] == -1 && s != t) {
      cout << "Brak ścieżki z węzła " << s << " do węzła " << t << ".\n";
      return;
    }

    // Tablica do przechowywania ścieżki
    int path[n]; // Zakładamy, że n to maksymalna liczba węzłów w grafie
    int pathIndex = 0;

    // Rekonstrukcja ścieżki przy użyciu tablicy parent
    int current = t;
    while (current != -1) {
      path[pathIndex++] = current;
      current = parent[current];
    }

    // Wyświetlenie ścieżki w odwrotnej kolejności
    cout << "Najkrótsza ścieżka z węzła " << s << " do węzła " << t << ": ";
    for (int i = pathIndex - 1; i >= 0; i--) {
      cout << path[i];
      if (i > 0)
        cout << " -> ";
    }
    cout << endl;
  }

  void Warshall_Floyd() {
    // Tworzenie i inicjalizacja tablic d[][]
    double **d = new double *[n];
    for (int i = 0; i < n; i++) {
      d[i] = new double[n];
      for (int j = 0; j < n; j++) {
        d[i][j] = adjWeightMatrix[i][j]; // adjWeightMatrix to macierz wag grafu
      }
    }

    // Główna część algorytmu (zgodnie z pseudokodem)
    for (int k = 0; k < n; k++) {     // Etap k (przejściowy wierzchołek)
      for (int i = 0; i < n; i++) {   // Źródło
        for (int j = 0; j < n; j++) { // Cel
          if (d[i][j] >
              d[i][k] + d[k][j]) { // Jeśli jest krótsza ścieżka przez k
            d[i][j] = d[i][k] + d[k][j]; // Aktualizuj wartość
          }
        }
      }
    }

    // Wyświetlenie wyników
    cout << "Macierz odległości najkrótszych ścieżek:\n";
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        if (d[i][j] == numeric_limits<double>::infinity()) {
          cout << "INF "; // Jeśli nie ma ścieżki między wierzchołkami
        } else {
          cout << d[i][j] << "\t";
        }
      }
      cout << endl;
    }

    // Zwolnienie pamięci
    for (int i = 0; i < n; i++) {
      delete[] d[i];
    }
    delete[] d;
  }

  friend ostream &operator<<(ostream &out, WeightedGraph &g) {
    for (int i = 0; i < g.n; i++) {
      for (int j = 0; j < g.n; j++) {
        out << g.adjWeightMatrix[i][j] << "\t";
      }
      out << endl;
    }
    return out;
  };

  ~WeightedGraph() {
    for (int i = 0; i < n; i++) {
      delete[] adjWeightMatrix[i];
    }
    delete[] adjWeightMatrix;
  };
};

int main() {
  // int n = 6, m = 15;
  int n = 10, m = 19;
  weightedEdge directedWeightedGraph[] = {
      {0, 1, 5}, // Krawędź z wierzchołka 0 do 1 z wagą 5

      {1, 2, 2}, // Krawędź z wierzchołka 0 do 2 z wagą 3
      {1, 7, 3}, // Krawędź z wierzchołka 0 do 3 z wagą 8

      {2, 3, 7}, // Krawędź z wierzchołka 1 do 2 z wagą 2
      {2, 8, 6}, // Krawędź z wierzchołka 1 do 4 z wagą 7

      {3, 2, 7}, // Krawędź z wierzchołka 2 do 0 z wagą 6
      {3, 9, 5}, // Krawędź z wierzchołka 2 do 3 z wagą 4

      {4, 0, 2}, // Krawędź z wierzchołka 2 do 4 z wagą 9

      {5, 3, 2}, // Krawędź z wierzchołka 3 do 1 z wagą 1
      {5, 8, 5}, // Krawędź z wierzchołka 3 do 4 z wagą 5

      {6, 0, 5}, // Krawędź z wierzchołka 4 do 0 z wagą 7
      {6, 7, 5}, // Krawędź z wierzchołka 4 do 2 z wagą 8

      {7, 1, 3}, // Krawędź z wierzchołka 4 do 0 z wagą 7
      {7, 4, 1}, // Krawędź z wierzchołka 4 do 2 z wagą 8
      {7, 6, 5}, // Krawędź z wierzchołka 4 do 2 z wagą 8
      {7, 8, 1}, // Krawędź z wierzchołka 4 do 2 z wagą 8

      {8, 5, 5}, // Krawędź z wierzchołka 4 do 2 z wagą 8
      {8, 7, 1}, // Krawędź z wierzchołka 4 do 2 z wagą 8

      {9, 8, 4} // Krawędź z wierzchołka 4 do 2 z wagą 8
  };
  WeightedGraph h(n, m, directedWeightedGraph, true);
  h.dijkstra(0);

  // int n = 6, m = 9;

  // weightedEdge directedWeightedGraph[] = {
  //     {0, 1, 3}, // Krawędź z wierzchołka 0 do 1 z wagą 5
  //     {0, 4, 1}, // Krawędź z wierzchołka 0 do 2 z wagą 3

  //     {1, 2, 2}, // Krawędź z wierzchołka 0 do 3 z wagą 8

  //     {2, 3, 2}, // Krawędź z wierzchołka 1 do 2 z wagą 2
  //     {2, 4, 4}, // Krawędź z wierzchołka 1 do 4 z wagą 7

  //     {3, 4, 1}, // Krawędź z wierzchołka 2 do 0 z wagą 6

  //     {4, 1, 1}, // Krawędź z wierzchołka 2 do 3 z wagą 4
  //     {4, 5, 4}, // Krawędź z wierzchołka 2 do 4 z wagą 9

  //     {5, 0, 3}, // Krawędź z wierzchołka 3 do 1 z wagą 1
  // };

  // weightedEdge directedWeightedGraph[]={.......};
  // cout << h;
  // h.Warshall_Floyd();
  return 0;
}