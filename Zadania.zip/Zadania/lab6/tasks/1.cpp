#include <iostream>

using namespace std;

// Zadanie 1 :
// Dla grafu (skierowanego lub nieskierowanego) reprezentowanego w postaci
// macierzy sąsiedztwa proszę zaimplementować wskazane algorytmy
// przeszukiwania grafu. Algorytmy powinien wyświetlać węzły w kolejności
// odwiedzenia. Proszę przetestować poprawność działania algorytmów.

// Zadanie 2
// Do klasy Graph z zadania 1 proszę dodać i przetestować zmodyfikowaną
// wersję algorytmu bfs lub dfs, umożliwiającą stwierdzenie czy graf
// nieskierowany jest spójny. Metoda powinna zwracać prawdę jeśli graf jest
// spójny i fałsz jeśli nie jest. Testowanie powinno być przeprowadzone w
// taki sposób, aby każdy możliwy przypadek był sprawdzony.

// Zadanie 3
// Do klasy z zadania 2 proszę dodać i przetestować metodę void connected()
// umożliwiającą podzielenie grafu nieskierowanego na spójne składowe (w
// oparciu o algorytm bfs lub dfs).  W wyniku należy podać liczbę spójnych
// składowych oraz dla każdego węzła informację do której spójnej składowej
// należy. Testowanie powinno być przeprowadzone w taki sposób, aby każdy
// możliwy przypadek był sprawdzony.

struct edge {
  int s;
  int t;
};
class Graph {
private:
  int **adjMatrix;
  int n;         // liczba węzłów
  bool directed; // true - graf skierowany, false - graf nieskierowany
  void dfs(int s, int *visited); // wykonuje przeszukiwanie i wyświetla węzły w
                                 // porządku odwiedzenia
public:
  // tworzy graf w oparciu o pdaną listę krawędzi
  Graph(int n, int m, edge edges[], bool directed);

  // konstruktor domyślny z predefiniowanym grafem testowym
  Graph() {
    this->n = 6;
    this->directed = directed;
    adjMatrix = new int *[n];

    for (int i = 0; i < n; i++)
      adjMatrix[i] = new int[n]{0};

    adjMatrix[0][4] = 1;
    adjMatrix[0][5] = 1;
    adjMatrix[1][0] = 1;
    adjMatrix[1][2] = 1;
    adjMatrix[1][4] = 1;
    adjMatrix[2][1] = 1;
    adjMatrix[2][3] = 1;
    adjMatrix[2][4] = 1;
    adjMatrix[3][2] = 1;
    adjMatrix[3][5] = 1;
    adjMatrix[4][0] = 1;
    adjMatrix[4][1] = 1;
    adjMatrix[4][3] = 1;
    adjMatrix[5][3] = 1;
    adjMatrix[5][4] = 1;
  }

  // tworzy losowy graf o n węzłach i m krawędziach, skierowany lub
  // nieskierowany
  Graph(int n, int m, bool directed);

  // wykonuje przeszukiwanie i wyświetla węzły w porządku odwiedzenia
  void bfs(int s);

  // metoda pomocnicza dla dfs - tworzy tabelę visited i wywołuję metodę
  // prywatną dfs
  void dfs(int s);

  // wyświetla graf
  friend ostream &operator<<(ostream &out, Graph &g);

  ~Graph();
};

int main() {
  int n = 6, m = 15;

  // przykładowy graf
  edge directedGraph[] = {{0, 4}, {0, 5}, {1, 0}, {1, 2}, {1, 4},
                          {2, 1}, {2, 3}, {2, 4}, {3, 2}, {3, 5},
                          {4, 0}, {4, 1}, {4, 3}, {5, 3}, {5, 4}};

  // lub Graph g; jeśli używany jest konstruktor domyślny z
  // predefiniowanym grafem testowym
  //   Graph g(n, m, directedGraph, true);

  //   cout << g;
  //   g.bfs(0);
  //   g.dfs(0);
}
