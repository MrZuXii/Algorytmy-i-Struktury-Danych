#include <cstdlib>
#include <iostream>

using namespace std;

// Dla grafu (skierowanego lub nieskierowanego) reprezentowanego w postaci
// macierzy sąsiedztwa proszę zaimplementować wskazane w szablonie operacje.
// Proszę przetestować ich poprawność.

struct edge {
  int s;
  int t;
};

class Graph {
private:
  int **adjMatrix;
  int n;         // liczba węzłów
  bool directed; // true - graf skierowany, false - graf nieskierowany

public:
  // tworzy graf w oparciu o podaną listę krawędzi (m - liczba krawędzi, edges[]
  // - lista krawędzi
  Graph(int n, int m, edge edges[], bool directed) : n(n), directed(directed) {
    adjMatrix = new int *[n];

    for (int i = 0; i < n; i++) {
      adjMatrix[i] = new int[n]();
    }

    for (int i = 0; i < m; i++) {

      int s = edges[i].s;
      int t = edges[i].t;

      adjMatrix[s][t] = 1;

      if (!directed) {
        adjMatrix[t][s] = 1;
      }
    }
  };

  // tworzy graf losowy, o podanej liczbie węzłów i krawędzi
  Graph(int n, int m, bool directed) : n(n), directed(directed) {
    adjMatrix = new int *[n];
    for (int i = 0; i < n; i++) {
      adjMatrix[i] = new int[n]();
    }

    srand(time(0));

    int edgesAdded = 0;

    while (edgesAdded < m) {
      int s = rand() % n; // Losowy wierzchołek początkowy
      int t = rand() % n; // Losowy wierzchołek końcowy

      if (s != t && adjMatrix[s][t] == 0) {
        adjMatrix[s][t] = 1;
        if (!directed)
          adjMatrix[t][s] = 1;

        edgesAdded++;
      }
    }
  };

  // wyświetla graf w formie "listy sąsiedztwa"
  friend ostream &operator<<(ostream &out, Graph &g) {
    int n = g.n;

    for (int i = 0; i < n; i++) {
      out << i << ": ";
      for (int j = 0; j < n; j++) {
        if (g.adjMatrix[i][j] == 1) {
          out << j << " ";
        }
      }
      out << endl;
    }
    return out;
  };

  ~Graph() {
    for (int i = 0; i < n; i++) {
      delete[] adjMatrix[i];
    }
    delete[] adjMatrix;
  };
};

int main() {
  int n = 6, m = 15;
  edge directedGraph[] = {{0, 4}, {0, 5}, {1, 0}, {1, 2}, {1, 4},
                          {2, 1}, {2, 3}, {2, 4}, {3, 2}, {3, 5},
                          {4, 0}, {4, 1}, {4, 3}, {5, 3}, {5, 4}};
  // przykładowy graf
  // Graph g(n, m, directedGraph, true);
  Graph g(n, m, true);
  cout << g;

  return 0;
}