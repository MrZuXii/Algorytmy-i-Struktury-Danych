Graph(int n, int m, edge edges[], bool directed) : n(n), directed(directed) {
  adjMatrix = new int *[n];

  for (int i = 0; i < n; i++) {
    adjMatrix[i] = new int[n]();
  }

  for (int i = 0; i < m; i++) {
    int s = edges[i].s;
    int t = edges[i].t;

    adjMatrix[s][t] = 1;

    if (!directed)
      adjMatrix[t][s] = 1;
  }
};

WeightedGraph(int n, int m, weightedEdge edges[], bool directed)
    : n(n), directed(directed) {
  adjWeightMatrix = new double *[n];

  for (int i = 0; i < n; i++) {
    adjWeightMatrix[i] = new double[n];

    for (int j = 0; j < n; j++) {
      adjWeightMatrix[i][j] = (i == j) ? 0 : numeric_limits<double>::infinity();
    }
  }

  for (int i = 0; i < m; i++) {
    int s = edges[i].s;
    int t = edges[i].t;
    double w = edges[i].w;

    adjWeightMatrix[s][t] = w;

    if (!directed) {
      adjWeightMatrix[t][s] = w;
    }
  }
};

void dfs(int s, int *visited) {
  visited[s] = true;
  cout << s << " ";
  for (int i = 0; i < n; i++) {
    if (adjMatrix[s][i] == 1 && !visited[i]) {
      dfs(i, visited);
    }
  }
};

void bfs(int s) {
  int *visited = new int[n]();
  int *parent = new int[n];

  for (int i = 0; i < n; i++)
    parent[i] = -1;

  queue<int> q;

  visited[s] = true;
  q.push(s);

  while (!q.empty()) {
    int u = q.front();
    cout << u << " ";
    q.pop();

    for (int i = 0; i < n; i++) {
      if (adjMatrix[u][i] == 1 && !visited[i]) {
        visited[i] = true;
        parent[i] = u;
        q.push(i);
      }
    }
  }

  cout << endl;
  delete[] visited;
  delete[] parent;
};

int find(double *d, bool *S, int n) {
  int minIndex = -1;
  double minValue = numeric_limits<double>::infinity();

  for (int i = 0; i < n; i++) {
    if (!S[i] && d[i] < minValue) {
      minValue = d[i];
      minIndex = i;
    }
  }

  return minIndex;
}

void dijkstra(int s) {
  bool *S = new bool[n];
  double *d = new double[n];
  int *parent = new int[n];

  for (int i = 0; i < n; i++) {
    d[i] = numeric_limits<double>::infinity();
    S[i] = false;
    parent[i] = -1;
  }
  d[s] = 0;

  for (int i = 0; i < n; i++) {
    int u = find(d, S, n);
    S[u] = true;

    for (int j = 0; j < n; j++) {
      if (d[j] > d[u] + adjWeightMatrix[u][j]) {
        d[j] = d[u] + adjWeightMatrix[u][j];
        parent[j] = u;
      }
    }
  }

  cout << "Odległości od wierzchołka " << s << ":\n";
  for (int i = 0; i < n; i++) {
    if (d[i] == numeric_limits<double>::infinity()) {
      cout << "Do wierzchołka " << i << ": brak połączenia\n";
    } else {
      cout << "Do wierzchołka " << i << ": " << d[i];
      if (parent[i] != -1) {
        cout << " (poprzednik: " << parent[i] << ")";
      }
      cout << endl;
    }
  }

  delete[] S;
  delete[] d;
  delete[] parent;
}