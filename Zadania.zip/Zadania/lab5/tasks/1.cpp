#include <iostream>

using namespace std;

// Dla grafu (skierowanego lub nieskierowanego) reprezentowanego w postaci
// macierzy sąsiedztwa proszę zaimplementować wskazane w szablonie operacje.
// Proszę przetestować ich poprawność.

struct edge {
  int s;
  int t;
};

class Graph {
private:
  int **adjMatrix;
  int n;         // liczba węzłów
  bool directed; // true - graf skierowany, false - graf nieskierowany

public:
  // tworzy graf w oparciu o podaną listę krawędzi (m - liczba krawędzi, edges[]
  // - lista krawędzi
  Graph(int n, int m, edge edges[], bool directed){};

  // tworzy graf losowy, o podanej liczbie węzłów i krawędzi
  Graph(int n, int m, bool directed){};

  // wyświetla graf w formie "listy sąsiedztwa"
  friend ostream &operator<<(ostream &out, Graph &g) {};
  ~Graph(){};
};

int main() {
  int n = 6, m = 15;
  // edge
  // directedGraph[]={{0,4},{0,5},{1,0},{1,2},{1,4},{2,1},{2,3},{2,4},{3,2},{3,5},{4,0},{4,1},{4,3},{5,3},{5,4}};
  // przykładowy graf
  // Graph g(n,m,directedGraph,true);
  // Graph g(n,m,true);
  // cout<<g;

  return 0;
}