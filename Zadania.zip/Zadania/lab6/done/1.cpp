#include <cstdlib>
#include <ctime>
#include <iostream>
#include <queue>

using namespace std;

// Zadanie 1 :
// Dla grafu (skierowanego lub nieskierowanego) reprezentowanego w postaci
// macierzy sąsiedztwa proszę zaimplementować wskazane algorytmy
// przeszukiwania grafu. Algorytmy powinien wyświetlać węzły w kolejności
// odwiedzenia. Proszę przetestować poprawność działania algorytmów.

// Zadanie 2
// Do klasy Graph z zadania 1 proszę dodać i przetestować zmodyfikowaną
// wersję algorytmu bfs lub dfs, umożliwiającą stwierdzenie czy graf
// nieskierowany jest spójny. Metoda powinna zwracać prawdę jeśli graf jest
// spójny i fałsz jeśli nie jest. Testowanie powinno być przeprowadzone w
// taki sposób, aby każdy możliwy przypadek był sprawdzony.

// Zadanie 3
// Do klasy z zadania 2 proszę dodać i przetestować metodę void connected()
// umożliwiającą podzielenie grafu nieskierowanego na spójne składowe (w
// oparciu o algorytm bfs lub dfs).  W wyniku należy podać liczbę spójnych
// składowych oraz dla każdego węzła informację do której spójnej składowej
// należy. Testowanie powinno być przeprowadzone w taki sposób, aby każdy
// możliwy przypadek był sprawdzony.

struct edge {
  int s;
  int t;
};
class Graph {
private:
  int **adjMatrix;
  int n;         // liczba węzłów
  bool directed; // true - graf skierowany, false - graf nieskierowany

  // wykonuje przeszukiwanie i wyświetla węzły w
  // porządku odwiedzenia
  void dfs(int s, int *visited) {
    visited[s] = true;
    cout << " " << s;

    for (int i = 0; i < n; i++) {
      if (adjMatrix[s][i] == 1 && !visited[i]) {
        dfs(i, visited);
      }
    }
  }

  void dfsIsConnected(int s, int *visited) {
    visited[s] = true;
    for (int i = 0; i < n; i++) {
      if (adjMatrix[s][i] == 1 && !visited[i]) {
        dfsIsConnected(i, visited);
      }
    }
  }

public:
  // tworzy graf w oparciu o pdaną listę krawędzi
  Graph(int n, int m, edge edges[], bool directed) : n(n), directed(directed) {
    adjMatrix = new int *[n];

    for (int i = 0; i < n; i++) {
      adjMatrix[i] = new int[n]();
    }

    for (int i = 0; i < m; i++) {
      int s = edges[i].s;
      int t = edges[i].t;

      adjMatrix[s][t] = 1;

      if (!directed) {
        adjMatrix[t][s] = 1;
      }
    }
  };

  // konstruktor domyślny z predefiniowanym grafem testowym
  Graph() {
    this->n = 6;
    this->directed = true;
    adjMatrix = new int *[n];

    for (int i = 0; i < n; i++)
      adjMatrix[i] = new int[n]{0};

    adjMatrix[0][4] = 1;
    adjMatrix[0][5] = 1;
    adjMatrix[1][0] = 1;
    adjMatrix[1][2] = 1;
    adjMatrix[1][4] = 1;
    adjMatrix[2][1] = 1;
    adjMatrix[2][3] = 1;
    adjMatrix[2][4] = 1;
    adjMatrix[3][2] = 1;
    adjMatrix[3][5] = 1;
    adjMatrix[4][0] = 1;
    adjMatrix[4][1] = 1;
    adjMatrix[4][3] = 1;
    adjMatrix[5][3] = 1;
    adjMatrix[5][4] = 1;
  }

  // tworzy losowy graf o n węzłach i m krawędziach, skierowany lub
  // nieskierowany
  Graph(int n, int m, bool directed) : n(n), directed(directed) {
    adjMatrix = new int *[n];

    srand(time(0));

    for (int i = 0; i < n; i++) {
      adjMatrix[i] = new int[n]();
    }

    int addedEdges = 0;
    while (addedEdges < m) {

      int s = rand() % n;
      int t = rand() % n;

      if (adjMatrix[s][t] != 1) {
        adjMatrix[s][t] = 1;
        if (!directed) {
          adjMatrix[t][s] = 1;
        }
        addedEdges++;
      }
    }
  };

  // wykonuje przeszukiwanie i wyświetla węzły w porządku odwiedzenia
  void bfs(int s) {
    int *visited = new int[n]();
    int *parent = new int[n];

    for (int i = 0; i < n; i++) {
      parent[i] = -1;
    }

    queue<int> q;

    visited[s] = true;
    q.push(s);

    cout << "[BFS] Wyświetla węzły w porządku odwiedzenia: ";

    while (!q.empty()) {
      int u = q.front();
      cout << u << " ";
      q.pop();
      for (int i = 0; i < n; i++) {
        if (adjMatrix[u][i] == 1 && !visited[i]) {
          visited[i] = true;
          parent[i] = u;
          q.push(i);
        }
      }
    }
    cout << endl;

    delete[] visited;
    delete[] parent;
  };

  void bfsIsConnected(int s) {
    int *visited = new int[n]();

    queue<int> q;

    visited[s] = true;
    q.push(s);

    while (!q.empty()) {
      int u = q.front();
      q.pop();
      for (int i = 0; i < n; i++) {
        if (adjMatrix[u][i] == 1 && !visited[i]) {
          visited[i] = true;
          q.push(i);
        }
      }
    }

    bool isConnected = true;

    for (int i = 0; i < n; i++) {
      if (visited[i] == 0) {
        isConnected = false;
        break;
      }
    }

    if (isConnected) {
      cout << "Graf jest spójny" << endl;
    } else {
      cout << "Graf nie jest spójny" << endl;
    }

    delete[] visited;
  }

  void dfsIsConnected(int s) {
    int *visited = new int[n]();
    dfsIsConnected(s, visited);

    int isConnected = true;

    for (int i = 0; i < n; i++) {
      if (!visited[i]) {
        isConnected = false;
        break;
      }
    }

    if (isConnected) {
      cout << "Graf jest spójny" << endl;
    } else {
      cout << "Graf nie jest spójny" << endl;
    }

    delete[] visited;
  }

  // metoda pomocnicza dla dfs - tworzy tabelę visited i wywołuję metodę
  // prywatną dfs
  void dfs(int s) {
    int *visited = new int[n]();
    cout << "[DFS] Wyświetla węzły w porządku odwiedzenia: ";
    dfs(s, visited);
    cout << endl;
    delete[] visited;
  };

  // wyświetla graf
  friend ostream &operator<<(ostream &out, Graph &g) {
    int **adjMatrix = g.adjMatrix;

    for (int i = 0; i < g.n; i++) {
      for (int y = 0; y < g.n; y++) {
        out << adjMatrix[i][y] << " ";
      }
      out << endl;
    }
    return out;
  };

  ~Graph() {
    for (int i = 0; i < n; i++) {
      delete[] adjMatrix[i];
    }
    delete[] adjMatrix;
  };
};

int main() {
  // int n = 6, m = 15;

  // przykładowy graf
  // edge directedGraph[] = {{0, 4}, {0, 5}, {1, 0}, {1, 2}, {1, 4},
  //                         {2, 1}, {2, 3}, {2, 4}, {3, 2}, {3, 5},
  //                         {4, 0}, {4, 1}, {4, 3}, {5, 3}, {5, 4}};

  int n = 10, m = 18;
  edge directedGraph[] = {{0, 1}, {1, 2}, {1, 7}, {2, 3}, {2, 8}, {3, 2},
                          {3, 9}, {4, 0}, {5, 3}, {5, 8}, {6, 0}, {6, 7},
                          {7, 1}, {7, 4}, {7, 6}, {8, 7}, {8, 5}, {9, 8}};

  // lub Graph g; jeśli używany jest konstruktor domyślny z
  // predefiniowanym grafem testowym
  Graph g(n, m, directedGraph, true);
  // Graph g(n, m, false);

  // cout << g;
  g.bfsIsConnected(0);
  g.dfsIsConnected(0);

  // g.dfs(0);
}
