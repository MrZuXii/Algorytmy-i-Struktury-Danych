#include <iostream>

using namespace std;
// Drzewo binarne: kopiec binarny  i jego zastosowanie w realizacji kolejki
// priorytetowej

// Zadanie 1:

// Dla kopca binarnego proszę zaimplementować wskazane w szablonie operacje dla
// kopca typu max lub min. Proszę przetestować poprawność ich działania – testy
// powinny być opracowane w taki sposób, aby weryfikowały działanie operacji we
// wszystkich możliwych do zaistnienia przypadkach. Testy powinny być
// zaprezentowane w sposób czytelny i jednoznaczny.

class Heap {
private:
  int *kopiec;
  int capacity;
  int size;

public:
  // tworzy pusty kopiec o pojemności c
  Heap(int c);

  bool empty();

  bool full();

  // zwraca pozycję lewego syna
  int getLeft(int i);

  // zwraca pozycję prawego syna
  int getRight(int i);

  // zwraca pozycję ojca
  int getParent(int i);

  // zwraca rozmiar kopca
  int getSize();

  // ustawia rozmiar kopca na s
  void setSize(int s);

  // zwraca wartość z pozycji i
  int getValue(int i);

  // ustawia wartość x na pozycji i
  void setValue(int i, int x);

  // przywraca własność kopca metodą wynurzania
  void bottomUp(int i);

  // przywraca własność kopca metodą zatapiania
  void topDown(int i);

  // wstawia element z wartością x (tutaj wartość jest jednocześnie priorytetem)
  void insert(int x);

  // usuwa element z "maksymalną" wartością priorytetu
  void deleteP();

  // usuwa element na pozycji i
  void del(int i);

  friend std::ostream &operator<<(std::ostream &out, Heap &h);
};

int main() {
  Heap h(15);
  return 0;
};