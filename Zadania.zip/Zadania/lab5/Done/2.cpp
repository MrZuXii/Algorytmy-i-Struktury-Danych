#include <cstdlib> // do generowania liczb losowych
#include <ctime>
#include <iostream>
#include <limits>

// Dla grafu ważonego (skierowanego lub nieskierowanego) reprezentowanego w
// postaci macierzy sąsiedztwa proszę zaimplementować wskazane w szablonie
// operacje. Proszę przetestować ich poprawność.

using namespace std;

struct weightedEdge {
  int s;
  int t;
  double w; // waga krawędzi
};

class WeightedGraph {
private:
  double **adjWeightMatrix;
  int n; // liczba węzłów
  bool directed;

public:
  // tworzy graf w oparciu o podaną listę krawędzi z wagami
  WeightedGraph(int n, int m, weightedEdge edges[], bool directed)
      : n(n), directed(directed) {

    adjWeightMatrix = new double *[n];

    for (int i = 0; i < n; i++) {
      adjWeightMatrix[i] = new double[n];

      for (int j = 0; j < n; j++) {
        adjWeightMatrix[i][j] =
            (i == j) ? 0 : numeric_limits<double>::infinity();
      }
    }

    for (int i = 0; i < m; i++) {
      int s = edges[i].s;
      int t = edges[i].t;
      double w = edges[i].w;

      adjWeightMatrix[s][t] = w;

      if (!directed) {
        adjWeightMatrix[t][s] = w;
      }
    }
  };

  // tworzy losowy graf
  WeightedGraph(int n, int m, bool directed) : n(n), directed(directed) {
    adjWeightMatrix = new double *[n];
    srand(time(NULL));

    for (int i = 0; i < n; i++) {
      adjWeightMatrix[i] = new double[n];
      for (int j = 0; j < n; j++) {
        adjWeightMatrix[i][j] =
            (i == j) ? 0 : numeric_limits<double>::infinity();
      }
    }

    for (int i = 0; i < m; i++) {
      int s = rand() % n;
      int t = rand() % n;
      double w =
          (rand() % 100 + 1) / 10.0; // losowa waga krawędzi (od 0.1 do 10.0)

      if (adjWeightMatrix[s][t] != numeric_limits<double>::infinity() &&
          adjWeightMatrix[s][t] != 0) {
        i--;
      } else {
        adjWeightMatrix[s][t] = w;

        if (!directed) {
          adjWeightMatrix[t][s] = w;
        }
      }
    }
  };

  friend ostream &operator<<(ostream &out, WeightedGraph &g) {
    for (int i = 0; i < g.n; i++) {
      for (int j = 0; j < g.n; j++) {
        if (g.adjWeightMatrix[i][j] == numeric_limits<double>::infinity()) {
          out << "INF\t"; // INF oznacza brak połączenia
        } else {
          out << g.adjWeightMatrix[i][j] << "\t";
        }
      }
      out << endl;
    }
    return out;
  };

  ~WeightedGraph() {
    for (int i = 0; i < n; i++) {
      delete[] adjWeightMatrix[i];
    }
    delete[] adjWeightMatrix;
  };
};

int main() {
  weightedEdge edges[] = {
      {0, 1, 2.5},
      {1, 2, 3.0},
      {2, 0, 1.5},
      {1, 3, 4.0},
  };

  int n = 4; // Liczba wierzchołków
  int m = 4; // Liczba krawędzi

  WeightedGraph g1(n, m, edges, true); // Tworzymy graf nieskierowany
  cout << "Graf z listy krawędzi:" << endl;
  cout << g1;

  return 0;
}