
// Zadanie 1:

// Dla tablicy z haszowaniem przechowującej elementy z kluczem tekstowym
// (string) proszę zaimplementować wskazane w szablonie operacje. Proszę
// zastosować metodę próbkowanie liniowego do rozwiązania problemu kolizji.
// Proszę przetestować poprawność działania operacji. Testy powinny być
// zaprezentowane w sposób czytelny i jednoznaczny.

// Zadanie 2:

// Wykorzystując tablicę z haszowaniem z zadania 1 proszę wykonać eksperyment
// umożliwiający sprawdzenie:

// jak często pojawiając się kolizje, przy wstawianiu/wyszukiwaniu oraz

// ile prób wymaga wstawienie/wyszukanie pojedynczego klucza ,

// jak współczynnik zapełnienia tablicy wpływa na częstotliwość pojawiania się
// kolizji i liczbę prób przy wstawianiu klucza
//   int n = 40;      // początkowa pojemność tablicy z haszowaniem
//   string dane[40]; // tablica do przechowania danych do testowania, należy je
//   odczytać z pliku lub zainicjalizować nimi tablicę

#include <iostream>
#include <string>

using namespace std;

class HashTable {
private:
  string *t;
  int capacity;
  int size;

public:
  // konstruktor tworzący pustą tablicę o pojemności c
  HashTable(int c);

  bool empty();

  bool full();

  // funkcja haszująca dla klucza s
  int hashFunction(string s);

  // wstawienie danych d z kluczem s (tutaj d=s)
  void insert(string d);

  // wstawienie danych d z kluczem s (zwraca liczbę prób przy wystąpieniu
  // kolizji - 0 jeśli kolizja nie wystąpiła)
  // int insert1(string d);

  void del(string s); // usuwa dane z kluczem s

  string search(string s); // wyszukuje i zwraca dane z s

  // wyszukuje s (zwraca liczbę prób przy wystąpieniu kolizji - 0 jeśli kolizja
  // nie wystąpiła)
  // int search1(string s);

  // wypisuje tablicę (z numerami pól),
  // pozostawia puste dla wolnych pól
  friend ostream &operator<<(ostream &out, HashTable &ht);
};

int main(int argc, char **argv) {

  int n; // pojemność tablicy z haszowaniem
  HashTable h(n);

  // cout << "insert(...)" << h.insert(); // po każdym wstawieniu/usunięciu
  // klucza należy// wyświetlić aktualny stan h

  return 0;
}

// Przykładowe dane do testowania:

// Julia
// Zuzanna
// Zofia
// Lena
// Maja
// Hanna
// Amelia
// Alicja
// Maria
// Aleksandra
// Oliwia
// Natalia
// Wiktoria
// Emilia
// Antonina
// Laura
// Pola
// Iga
// Anna
// Liliana
// Antoni
// Jakub
// Jan
// Szymon
// Franciszek
// Filip
// Aleksander
// Mikolaj
// Wojciech
// Kacper
// Adam
// Michal
// Marcel
// Stanislaw
// Wiktor
// Piotr
// Igor
// Leon
// Nikodem
// Mateusz
