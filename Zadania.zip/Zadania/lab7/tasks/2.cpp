// Znajdywanie wzorca w tekście

// Zadanie 1:
// Dla tekstu T i wzorca p proszę zaimplementować algorytm naiwny wyszukiwania
// wzorca w tekście. Algorytm należy zaimplementować w postaci funkcji: void
// naiveStringMatching(string T, string p) wyświetlającej pozycje w tekście, od
// których występuje wzorzec. Proszę przetestować poprawność działania
// algorytmu. Testy powinny być zaprezentowane w sposób czytelny i jednoznaczny.

// wywołanie naiveStringMatching() i wyświetlenie wyników (wszystkich pozycji,
// od których został znaleziony wzorzec)

// Przykładowy tekst i wzorzec do testów:

// string
// text="gfrgfgigjmgfrrogirgfrgfrgfrgirhgrygfrgfygirmggfrgfgfrgffeutyitbhfuvwgfrgf";
// string pattern="gfrgf";

// Wynik: 0 18 21 34 45 50 68

// Zadanie 2:

// Dla tekstu T i wzorca p proszę zaimplementować algorytm Boyera-Moore'a
// (wersja uproszczona). Algorytm należy zaimplementować w postaci funkcji: void
// BoyerMoore(string T, string p) wyświetlającej pozycje w tekście, od których
// występuje wzorzec. Proszę przetestować poprawność działania algorytmu. Testy
// powinny być zaprezentowane w sposób czytelny i jednoznaczny.

// Zadanie 3:

// Wykorzystując funkcje z zadań 1-3 proszę porównać algorytmy pod względem
// czasu. W ramach eksperymentu porównanie należy powtórzyć wielokrotnie dla
// losowo generowanych (lub rzeczywistych) tekstów i wzorców, każdorazowo
// wyświetlając czas dla każdego algorytmu.

// Zadanie 4:

// Dla tekstu T i wzorca p proszę zaimplementować algorytm Karpa-Rabina.
// Algorytm należy zaimplementować w postaci funkcji: void RabinKarp(string T,
// string p) wyświetlającej pozycje w tekście, od których występuje wzorzec.
// Proszę przetestować poprawność działania algorytmu i dodać go do porównania z
// zadania 3. Testy powinny być zaprezentowane w sposób czytelny i jednoznaczny.

#include <iostream>
#include <string>

using namespace std;

// Zadanie 1
void naiveStringMatching(string T, string p) {}

// Zadanie 2
void BoyerMoore(string T, string p) {}

// Zadanie 3

// funkcja generująca tekst o długości n
string textGenerator(int n);

// Zadanie 4
void KarpRabin(string T, string p) {}

int main() {

  string text = "gfrgfgigjmgfrrogirgfrgfrgfrgirhgrygfrgfygirmggfrgfgfrgffeutyit"
                "bhfuvwgfrgf";
  string pattern = "gfrgf";

  // Wynik: 0 18 21 34 45 50 68
  return 0;
}
