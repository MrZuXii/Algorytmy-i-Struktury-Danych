// Zadanie 1:

// Dla n losowo wygenerowanych liczb naturalnych, przechowywanych w tablicy S,
// proszę zaimplementować proste algorytmy sortowania. Algorytmy należy
// zaimplementować w postaci oddzielnych funkcji. Proszę przetestować poprawność
// ich działania według podanego w szablonie schematu.

// Zadanie 2:

// Do programu z zdania 1 proszę dodać kod implementujący eksperymentalne
// porównanie algorytmów z zadania 1, uwzględniając czas ich działania.

// Wykonanie eksperymentu wymaga:

// wybrania odpowiednio dużego rozmiaru tablicy
// generację losowych danych (oraz utworzenia ich kopii)
// sortowanie danych przy użyciu algorytmów z zadania 1 i zmierzenia i
// wyświetlenia czasu trwania sortowania dla każdego z nich Pomiar czasu:

//     clock_t start = clock();
//     //wywołanie funkcji
//     clock_t end = clock();
//     double result_time = (double) (end - start) /CLOCKS_PER_SEC;

// Pomiar czasu wymaga dołączenia bibliotek cstdlib i ctime.

// Zadanie 3:
// Do programu z zadania 2 proszę dodać i zaimplementować algorytm sortowania
// szybkiego i/lub sortowania przez scalanie, przetestować go według schematu
// dla zadania 1 oraz dodać do porównania z zadania 2.

// Szablon rozwiązania:

// //Zadanie 3
// void quickSort(int* S, int left, int right){
// }

// void mergeSort(int* S, int left, int right){
// }

// Zadanie 4:

// Do programu z zadania 3 proszę dodać i zaimplementować algorytm sortowania
// przez zliczanie, przetestować go według schematu dla zadania 1 oraz dodać do
// porównania z zadania 3.

// Szablon rozwiązania:

// //Zadanie 4
// void cntSort(int* S, int n, int k){   //k zakres liczb <0 - k)
// }

#include <algorithm> // Include this for max_element
#include <cstdlib>
#include <ctime>
#include <iostream>

using namespace std;

// wyświetla dane
void print(int *S, int n) {
  for (int i = 0; i < n; i++) {
    cout << S[i] << " ";
  }
  cout << endl;
}

// generuje losowe dane
void init(int *S, int n) {
  srand(time(0));
  for (int i = 0; i < n; i++) {
    S[i] = 1 + (rand() % 100); // Losowa liczba w zakresie 1-100;
  }
}

void insertionSort(int *S, int n) {
  for (int i = 1; i < n; i++) {
    int aux = S[i]; // Przechowaj element do wstawienia
    int j;

    // Przesuwaj elementy większe od aux
    for (j = i - 1; j >= 0; j--) {
      if (S[j] > aux)
        S[j + 1] = S[j];
      else
        break; // Zakończ przesuwanie, gdy znajdziesz mniejsze lub równe
    }

    // Wstaw aux na właściwe miejsce
    S[j + 1] = aux;
  }
}

void selectionSort(int *S, int n) {
  for (int i = 0; i < n - 1; i++) {
    int min = i;
    for (int j = i + 1; j < n; j++) {
      if (S[j] < S[min])
        min = j;
    }
    swap(S[i], S[min]);
  }
}

void bubbleSort(int *S, int n) {
  for (int i = 1; i < n; i++) { // Pętla zewnętrzna od 1 do n-1
    bool zamiana = false;       // Flaga wskazująca, czy dokonano zamiany

    for (int j = n - 1; j >= i; j--) { // Pętla wewnętrzna od n-1 do i
      if (S[j] < S[j - 1]) { // Sprawdzanie, czy elementy są w złej kolejności
        swap(S[j], S[j - 1]); // Zamiana sąsiadujących elementów
        zamiana = true;       // Oznaczamy, że była zamiana
      }
    }
    if (!zamiana)
      break; // Jeśli nie było żadnej zamiany, zakończ sortowanie
  }
}

int split(int *S, int left, int right) {
  int pivot = S[right]; // Wybieramy ostatni element jako pivot
  int i = left - 1;     // Inicjalizujemy wskaźnik i na lewą stronę

  // 5. Pętla przez elementy
  for (int j = left; j < right; j++) {
    // 6. Porównanie elementu z pivotem
    if (S[j] < pivot) {
      i++;              // 7. Zwiększenie wskaźnika i
      swap(S[i], S[j]); // 8. Zamiana elementu z i
    }
  }

  // 9. Zamiana pivota na odpowiednią pozycję
  swap(S[i + 1], S[right]);

  // Zwrócenie ostatecznej pozycji pivota
  return i + 1;
}

void quickSort(int *S, int left, int right) {
  if (left < right) {
    int pivotindex = split(S, left, right);
    quickSort(S, left, pivotindex - 1);
    quickSort(S, pivotindex + 1, right);
  }
}

// Funkcja scalająca dwie posortowane tablice
void merge(int *S, int left, int mid, int right) {
  int n1 = mid - left + 1; // Rozmiar lewej podtablicy
  int n2 = right - mid;    // Rozmiar prawej podtablicy

  // Tworzymy dwie pomocnicze tablice
  int *aux = new int[n1 + n2];

  int i = 0, j = 0, k = left;

  // Łączenie dwóch posortowanych części
  while (i < n1 && j < n2) {
    if (S[left + i] <= S[mid + 1 + j]) {
      aux[k - left] = S[left + i];
      i++;
    } else {
      aux[k - left] = S[mid + 1 + j];
      j++;
    }
    k++;
  }

  // Kopiowanie pozostałych elementów z lewej części, jeśli istnieją
  while (i < n1) {
    aux[k - left] = S[left + i];
    i++;
    k++;
  }

  // Kopiowanie pozostałych elementów z prawej części, jeśli istnieją
  while (j < n2) {
    aux[k - left] = S[mid + 1 + j];
    j++;
    k++;
  }

  // Kopiowanie posortowanych danych z tablicy pomocniczej do oryginalnej
  // tablicy
  for (i = 0; i < n1 + n2; i++) {
    S[left + i] = aux[i];
  }

  delete[] aux; // Zwolnienie pamięci tablicy pomocniczej
}

void mergeSort(int *S, int left, int right) {
  if (left < right) {
    int mid = (left + right) / 2;
    mergeSort(S, left, mid);
    mergeSort(S, mid + 1, right);
    merge(S, left, mid, right);
  }
}

void cntSort(int *items, int n, int k) {
  // Tablica wyjściowa
  int *o_items = new int[n];

  // Tablica pomocnicza do zliczania
  int *cnt = new int[k + 1](); // Zainicjalizuj tablicę pomocniczą z zerami

  // (4) Zliczanie wystąpień każdego elementu
  for (int i = 0; i < n; i++) {
    cnt[items[i]] = cnt[items[i]] + 1;
  }

  // (6) Akumulowanie sumy, by uzyskać pozycje
  for (int j = 1; j <= k; j++) {
    cnt[j] = cnt[j] + cnt[j - 1];
  }

  // (8) Przenoszenie elementów do tablicy wyjściowej w odwrotnej kolejności
  for (int i = n - 1; i >= 0; i--) {
    o_items[cnt[items[i]] - 1] = items[i];
    cnt[items[i]] = cnt[items[i]] - 1; // Zmniejszenie liczby wystąpień
  }

  // Kopiowanie posortowanych danych z o_items z powrotem do items
  for (int i = 0; i < n; i++) {
    items[i] = o_items[i];
  }

  // Zwolnienie pamięci tablic pomocniczych
  delete[] o_items;
  delete[] cnt;
}

int *copyArray(int *S, int n) {
  int *newArray = new int[n];
  for (int i = 0; i < n; i++) {
    newArray[i] = S[i];
  }
  return newArray;
}

int main() {
  int n = 25000; // przykładowy rozmiar

  int *S = new int[n];
  init(S, n);
  int *S2 = copyArray(S, n);
  int *S3 = copyArray(S, n);
  int *S4 = copyArray(S, n);
  int *S5 = copyArray(S, n);
  int *S6 = copyArray(S, n);

  srand(time(0));
  int k = *max_element(S, S + n);

  clock_t start = clock();
  selectionSort(S, n);
  clock_t end = clock();
  double result_time = (double)(end - start) / CLOCKS_PER_SEC;

  clock_t start2 = clock();
  insertionSort(S2, n);
  clock_t end2 = clock();
  double result_time2 = (double)(end2 - start2) / CLOCKS_PER_SEC;

  clock_t start3 = clock();
  bubbleSort(S3, n);
  clock_t end3 = clock();
  double result_time3 = (double)(end3 - start3) / CLOCKS_PER_SEC;

  clock_t start4 = clock();
  quickSort(S4, 0, n - 1);
  clock_t end4 = clock();
  double result_time4 = (double)(end4 - start4) / CLOCKS_PER_SEC;

  clock_t start5 = clock();
  mergeSort(S5, 0, n - 1);
  clock_t end5 = clock();
  double result_time5 = (double)(end5 - start5) / CLOCKS_PER_SEC;

  clock_t start6 = clock();
  cntSort(S6, n, k);
  clock_t end6 = clock();
  double result_time6 = (double)(end6 - start6) / CLOCKS_PER_SEC;

  cout << "Czas wykonania sortowania przez wybieranie wynosi: " << result_time
       << endl;
  cout << "Czas wykonania sortowania przez wstawianie wynosi: " << result_time2
       << endl;
  cout << "Czas wykonania sortowania przez zamiane wynosi: " << result_time3
       << endl;
  cout << "Czas wykonania sortowania przez Sortowanie szybkie wynosi: "
       << result_time4 << endl;
  cout << "Czas wykonania sortowania przez Podział wynosi: " << result_time5
       << endl;
  cout << "Czas wykonania sortowania przez Scalanie wynosi: " << result_time6
       << endl;

  // print(S, n);
  // selectionSort(S, n);
  // insertionSort(S, n);
  // bubbleSort(S, n);
  // mergeSort(S, 0, n - 1);
  // int k = *max_element(S, S + n);
  // cntSort(S, n, k);
  // print(S, n);

  delete[] S;
  return 0;
}
