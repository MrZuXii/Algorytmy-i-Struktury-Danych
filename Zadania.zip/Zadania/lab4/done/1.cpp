#include <iostream>

using namespace std;
// Drzewo binarne: kopiec binarny  i jego zastosowanie w realizacji kolejki
// priorytetowej

// Zadanie 1:

// Dla kopca binarnego proszę zaimplementować wskazane w szablonie operacje dla
// kopca typu max lub min. Proszę przetestować poprawność ich działania – testy
// powinny być opracowane w taki sposób, aby weryfikowały działanie operacji we
// wszystkich możliwych do zaistnienia przypadkach. Testy powinny być
// zaprezentowane w sposób czytelny i jednoznaczny.

class Heap {
private:
  int *kopiec;
  int capacity;
  int size;

public:
  // tworzy pusty kopiec o pojemności c
  Heap(int c) : capacity(c), size(0) { kopiec = new int[c]; };

  bool empty() { return size == 0; };

  bool full() { return size == capacity; };

  // zwraca pozycję lewego syna
  int getLeft(int i) {
    if (2 * i + 1 < size)
      return 2 * i + 1;
    else
      return -1;
  };

  // zwraca pozycję prawego syna
  int getRight(int i) {
    if (2 * i + 2 < size)
      return 2 * i + 2;
    else
      return -1;
  };

  // zwraca pozycję ojca
  int getParent(int i) {
    if (i == 0)
      return -1;
    else
      return (i - 1) / 2;
  };

  // zwraca rozmiar kopca
  int getSize() { return size; };

  // ustawia rozmiar kopca na s
  void setSize(int s) { capacity = s; };

  // zwraca wartość z pozycji i
  int getValue(int i) {
    if (empty()) {
      cout << "Error: Kopiec pusty";
      return -1;
    }
    return kopiec[i];
  };

  // ustawia wartość x na pozycji i
  void setValue(int i, int x) {
    kopiec[i] = x;
    topDown(i);
    bottomUp(i);
  };

  // przywraca własność kopca metodą wynurzania
  void bottomUp(int i) {
    if (i > 0) {
      int p = getParent(i);
      if (kopiec[i] > kopiec[p]) {
        swap(kopiec[i], kopiec[p]);
        bottomUp(p);
      }
    }
  };

  // przywraca własność kopca metodą zatapiania
  void topDown(int i) {
    // Pobierz indeks lewego dziecka węzła i
    int left = getLeft(i);
    // Pobierz indeks prawego dziecka węzła i
    int right = getRight(i);

    // Zakładamy na początku, że największy element znajduje się w bieżącym
    // węźle (i)
    int g = i;

    // Jeśli lewe dziecko istnieje (left != -1) i jego wartość jest większa niż
    // wartość w bieżącym węźle (i), aktualizujemy g, aby wskazywało indeks
    // lewego dziecka
    if (left != -1 && kopiec[left] > kopiec[i])
      g = left;

    // Jeśli prawe dziecko istnieje (right != -1) i jego wartość jest większa
    // niż wartość w największym dotąd węźle (g), aktualizujemy g, aby
    // wskazywało indeks prawego dziecka
    if (right != -1 && kopiec[right] > kopiec[g])
      g = right;

    // Jeśli największy element nie znajduje się w bieżącym węźle (g != i),
    // zamień bieżący węzeł z największym dzieckiem
    if (g != i) {
      // Zamień wartości kopiec[i] i kopiec[g]
      swap(kopiec[i], kopiec[g]);

      // Rekurencyjnie wywołaj topDown dla indeksu g (gdzie przesunęliśmy
      // mniejszy element), aby upewnić się, że poddrzewo z korzeniem w g
      // również spełnia własność kopca
      topDown(g);
    }
  };

  // wstawia element z wartością x (tutaj wartość jest jednocześnie priorytetem)
  void insert(int x) {
    if (full()) {
      cout << "Error: Kopiec pełny" << endl;
      return;
    }
    kopiec[size] = x;
    bottomUp(size);
    size++;
  };

  // usuwa element z "maksymalną" wartością priorytetu
  void deleteP() {
    if (empty()) {
      cout << "Error: Kopiec pusty";
      return;
    }
    size--;
    swap(kopiec[0], kopiec[size]);
    topDown(0);
  };

  // usuwa element na pozycji i
  void del(int i) {
    if (empty()) {
      cout << "Error: Kopiec pusty";
      return;
    }
    size--;
    swap(kopiec[i], kopiec[size]);
    topDown(i);
    bottomUp(i);
  };

  friend std::ostream &operator<<(std::ostream &out, Heap &h) {
    for (int i = 0; i < h.size; i++) {
      out << h.kopiec[i] << " ";
    }
    out << endl;
    return out;
  };
};

int main() {
  Heap h(5); // kopiec o pojemności 5
  cout << "Wstawiamy elementy do kopca:" << endl;
  h.insert(5);
  h.insert(10);
  h.insert(7);
  h.insert(2);
  h.insert(15); // pełny kopiec
  cout << h;

  cout << "Usuwamy element o największym priorytecie:" << endl;
  h.deleteP();
  cout << h;

  cout << "Usuwamy element na pozycji 1:" << endl;
  h.del(1);
  cout << h;

  cout << "Wstawiamy element po usunięciu:" << endl;
  h.insert(20);
  cout << h;

  cout << "Próba wstawienia elementu do pełnego kopca:" << endl;
  h.insert(25); // dynamiczna zmiana rozmiaru
  cout << h;
  return 0;
};