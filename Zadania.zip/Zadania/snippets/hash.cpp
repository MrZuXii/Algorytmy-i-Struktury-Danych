#include <string>
int capacity;
using namespace std;
void full() {};

// funkcja haszująca dla klucza s
int hashFunction(string s) {
  int hash = 0;
  int prime = 31;
  int n = s.size();

  for (int i = 0; i < n; i++) {
    hash = (hash * prime + s[i]) % capacity;
  }
  return hash;
};

void insert(string d) {
  if (full()) {
    cout << "Error: Tablica jest pełna";
    return;
  }

  int hash = hashFunction(d);
  int i = 0;

  while (t[hash] != "" && t[hash] != "FREE" && i < capacity) {
    i++;
    hash = (hash + 1) % capacity;
  }
  t[hash] = d;
  size++;
};

void del(string s) {
  if (empty()) {
    cout << "Error: Tablica jest pusta";
    return;
  }
  int hash = hashFunction(s);
  int i = 0;

  while (t[hash] != s && i < capacity) {
    hash = (hash + 1) % capacity;
    i++;
  };
  if (i < capacity) {
    t[hash] = "FREE";
    size--;
  }
};

string search(string s) {
  if (empty()) {
    cout << "Error: Tablica jest pusta";
    return "Error: Tablica jest pusta";
  }
  int hash = hashFunction(s);
  int collision = 0;

  while (t[hash] != s && collision < capacity) {
    hash = (hash + 1) % capacity;
    collision++;
  }
  if (collision < capacity) {
    return t[hash];
  }
  return "Nie znaleziono";
};