// Znajdywanie wzorca w tekście

// Zadanie 1:
// Dla tekstu T i wzorca p proszę zaimplementować algorytm naiwny wyszukiwania
// wzorca w tekście. Algorytm należy zaimplementować w postaci funkcji: void
// naiveStringMatching(string T, string p) wyświetlającej pozycje w tekście, od
// których występuje wzorzec. Proszę przetestować poprawność działania
// algorytmu. Testy powinny być zaprezentowane w sposób czytelny i jednoznaczny.

// wywołanie naiveStringMatching() i wyświetlenie wyników (wszystkich pozycji,
// od których został znaleziony wzorzec)

// Przykładowy tekst i wzorzec do testów:

// string
// text="gfrgfgigjmgfrrogirgfrgfrgfrgirhgrygfrgfygirmggfrgfgfrgffeutyitbhfuvwgfrgf";
// string pattern="gfrgf";

// Wynik: 0 18 21 34 45 50 68

// Zadanie 2:

// Dla tekstu T i wzorca p proszę zaimplementować algorytm Boyera-Moore'a
// (wersja uproszczona). Algorytm należy zaimplementować w postaci funkcji: void
// BoyerMoore(string T, string p) wyświetlającej pozycje w tekście, od których
// występuje wzorzec. Proszę przetestować poprawność działania algorytmu. Testy
// powinny być zaprezentowane w sposób czytelny i jednoznaczny.

// Zadanie 3:

// Wykorzystując funkcje z zadań 1-3 proszę porównać algorytmy pod względem
// czasu. W ramach eksperymentu porównanie należy powtórzyć wielokrotnie dla
// losowo generowanych (lub rzeczywistych) tekstów i wzorców, każdorazowo
// wyświetlając czas dla każdego algorytmu.

// Zadanie 4:

// Dla tekstu T i wzorca p proszę zaimplementować algorytm Karpa-Rabina.
// Algorytm należy zaimplementować w postaci funkcji: void RabinKarp(string T,
// string p) wyświetlającej pozycje w tekście, od których występuje wzorzec.
// Proszę przetestować poprawność działania algorytmu i dodać go do porównania z
// zadania 3. Testy powinny być zaprezentowane w sposób czytelny i jednoznaczny.

#include <cstdlib>
#include <ctime>
#include <iostream>
#include <math.h>
#include <string>

using namespace std;

// Zadanie 1
void naiveStringMatching(string T, string p) {
  int n = T.size();
  int m = p.size();
  for (int s = 0; s <= n - m; s++) {
    int i = 0;
    while (i < m && p[i] == T[s + i])
      i++;
    if (i == m)
      cout << "Wzorzec wystąpił z przesunięciem " << s << endl;
  }
}

// Zadanie 2
void BoyerMoore(string T, string p) {
  int n = T.size();
  int m = p.size();

  // Tworzenie tablicy bad character (bc) o rozmiarze 256 dla ASCII
  int bc[256];
  for (int i = 0; i < 256; i++) {
    bc[i] = -1; // Inicjalizacja: brak wystąpienia znaku w wzorcu
  }

  // Wypełnianie tablicy bc na podstawie wzorca P
  for (int i = 0; i < m; i++) {
    bc[p[i]] = i; // Zapisujemy ostatnie wystąpienie każdego znaku
  }

  int s = 0; // Przesunięcie wzorca względem tekstu

  // Dopóki wzorzec mieści się w tekście
  while (s <= n - m) {
    int i = m - 1; // Zaczynamy od końca wzorca

    // Porównywanie wzorca od końca
    while (i >= 0 && p[i] == T[s + i]) {
      i--;
    }

    if (i == -1) { // Jeśli znaleziono dopasowanie
      cout << "Wzorzec wystąpił z przesunięciem " << s << endl;
      s = s + 1; // (6) Przesunięcie wzorca o 1
    } else {
      // Przypadek 1: znak T[s + i] nie występuje w wzorcu
      if (bc[T[s + i]] == -1) {
        s += i + 1;
      }
      // Przypadek 2: znak T[s + i] występuje, ale w złej pozycji
      else if (bc[T[s + i]] < i) {
        s += i - bc[T[s + i]];
      }
      // Przypadek 3: znak T[s + i] występuje w odpowiedniej pozycji
      else {
        s += 1;
      }
    }
  }
}

// Zadanie 3 nie dziala

// funkcja generująca tekst o długości n
string textGenerator(int n) {
  string text;
  for (int i = 0; i < n; i++) {
    char randomLetter = 'a' + rand() % 26;
    text.push_back(randomLetter);
  }
  return text;
};

// Zadanie 4

// Funkcja do obliczania haszu dla tekstu
int hashValue(const string &str, int m) {
  int hash = 0;
  int base = 10;

  // Stosujemy wzór do obliczenia wartości hasza
  for (int i = 0; i <= m; i++) {
    cout << str[i] * 1 << endl;
    hash += str[i] * pow(base, m - i); // mnożymy przez odpowiednią potęgę bazy
  }

  return hash;
}

// Funkcja porównująca dwa ciągi
bool compare(const string &P, int m, const string &T, int s) {
  for (int i = 0; i < m; i++) {
    if (P[i] != T[s + i]) {
      return false; // Jeśli jakiekolwiek znaki się różnią, zwróć false
    }
  }
  return true; // Wszystkie znaki są takie same
}

int rehash(int hs, char removed, char added) {
  int base = 10; // Baza dla haszowania
  int m = 3; // Długość wzorca - zmień to na odpowiednią wartość w zależności od
             // Twojego przypadku
  int mod =
      10000; // Modyfikator - odpowiednia wartość zależna od Twoich potrzeb

  // Wzór rehashowania
  hs = (hs - removed * pow(base, m - 1)) * base + added;

  // Zapewnienie, że wynik będzie dodatni i w odpowiednim zakresie
  hs = (hs + mod) % mod;

  return hs;
}

// Główny algorytm Karp-Rabin
void KarpRabin(string T, string P) {
  int n = T.size();
  int m = P.size();

  int hp = hashValue(P, m - 1); // Obliczanie haszu wzorca
  int hs = hashValue(T, m - 1); // Obliczanie haszu pierwszych m znaków tekstu

  for (int s = 0; s <= n - m; s++) {
    if (hp == hs) {                     // Jeśli hasze są równe
      bool match = compare(P, m, T, s); // Porównaj wzorzec i tekst
      if (match) {
        cout << "Wzorzec wystąpił z przesunięciem " << s << endl;
      }
    }

    // Jeśli nie jesteśmy na końcu tekstu
    if (s < n - m) {
      hs = rehash(hs, T[s],
                  T[s + m]); // Przeliczenie haszu dla kolejnego przesunięcia
    }
  }
}

int main() {

  //   string text =
  //       "gfrgfgigjmgfrrogirgfrgfrgfrgirhgrygfrgfygirmggfrgfgfrgffeutyitbhfuvwg"
  //       "frgf";
  //   string pattern = "gfrgf";
  //   naiveStringMatching(text, pattern);
  //   BoyerMoore(text, pattern);
  //   KarpRabin(text, pattern);

  string str = "aaaa"; // Przykładowy tekst

  cout << hashValue(str, 3);

  // Zadanie 3
  //   {
  //     srand(time(0));
  //     double result_time = 0.0;
  //     double result_timeBoyerMoore = 0.0;
  //     double result_timeKarpRabin = 0.0;

  //     for (int i = 0; i < 1000; i++) {
  //       string text = textGenerator(1000);
  //       string pattern = text.substr(rand() % (1000 - 4), 4);

  //       clock_t start = clock();
  //       naiveStringMatching(text, pattern);
  //       clock_t end = clock();

  //       clock_t startBoyerMoore = clock();
  //       BoyerMoore(text, pattern);
  //       clock_t endBoyerMoore = clock();

  //       clock_t startKarpRabin = clock();
  //       KarpRabin(text, pattern);
  //       clock_t endKarpRabin = clock();

  //       result_time += (double)(end - start) / CLOCKS_PER_SEC;
  //       result_timeBoyerMoore +=
  //           (double)(endBoyerMoore - startBoyerMoore) / CLOCKS_PER_SEC;

  //       result_timeKarpRabin +=
  //           (double)(endKarpRabin - startKarpRabin) / CLOCKS_PER_SEC;
  //     }
  //     cout << "Czas potrzebny dla naiveStringMatching wynosi: " <<
  //     result_time
  //          << endl;
  //     cout << "Czas potrzebny dla BoyerMoore wynosi: " <<
  //     result_timeBoyerMoore
  //          << endl;
  //     cout << "Czas potrzebny dla KarpRabin wynosi: " << result_timeKarpRabin
  //          << endl;
  //   }
  return 0;
}
