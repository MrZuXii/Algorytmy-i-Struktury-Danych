#include <iostream>
#include <math.h>
#include <string>

using namespace std;

void naiveStringMatching(string T, string p) {
  int n = T.size();
  int m = p.size();

  for (int s = 0; s <= n - m; s++) {
    int i = 0;
    while (i < m && T[s + i] == p[i]) {
      i++;
    }
    if (i == m)
      cout << s << " ";
  }
}

void BoyerMoore(string T, string p) {
  int n = T.size();
  int m = p.size();

  int *bc = new int[256];

  for (int i = 0; i < 256; i++) {
    bc[i] = -1;
  }

  for (int i = 0; i < m; i++) {
    bc[p[i]] = i;
  }

  int s = 0;

  while (s <= n - m) {
    int i = m - 1;

    while (i >= 0 && T[s + i] == p[i]) {
      i--;
    }

    if (i == -1) {
      cout << s << " ";
      s++;
    } else {
      if (bc[T[s + i]] == -1)
        s = s + i + 1;

      else if (bc[T[s + i]] < i)
        s = s + i - bc[T[s + i]];

      else
        s++;
    }
  }

  delete[] bc;
}

int hashValue(const string &str, int m) {
  int hash = 0;
  int base = 10;

  for (int i = 0; i < m; i++) {
    hash += str[i] * pow(base, m - i - 1);
  }

  return hash;
}

int rehash(int hs, char oldChar, char newChar, int m) {
  int base = 10;
  hs = (hs - oldChar * pow(base, m - 1)) * base + newChar;
  return hs;
}

bool compare(string T, int s, string p, int m) {
  for (int i = 0; i < m; i++) {
    if (T[s + i] != p[i])
      return false;
  }
  return true;
}

void KarpRabin(string T, string p) {
  int n = T.size();
  int m = p.size();

  int hashp = hashValue(p, m);
  int hashT = hashValue(T, m);

  for (int s = 0; s <= n - m; s++) {
    if (hashp == hashT) {
      bool match = compare(T, s, p, m);
      if (match) {
        cout << s << " ";
      }
    }

    if (s < n - m) {
      hashT = rehash(hashT, T[s], T[s + m], m);
    }
  }
}