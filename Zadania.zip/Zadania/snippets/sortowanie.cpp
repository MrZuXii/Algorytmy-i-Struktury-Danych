#include <iostream>
using namespace std;

// Sortowanie przez wybieranie
void selectionSort(int *S, int n) {
  for (int i = 0; i < n - 1; i++) {
    int min = i;
    for (int j = i + 1; j < n; j++) {
      if (S[min] > S[j])
        min = j;
    }
    swap(S[min], S[i]);
  }
}

// Sortowanie przez wstawianie
void insertionSort(int *S, int n) {
  for (int i = 1; i < n; i++) {
    int aux = S[i];
    int j;
    for (j = i - 1; j >= 0; j--) {
      if (S[j] > aux)
        S[j + 1] = S[j];
      else
        break;
    }
    S[j + 1] = aux;
  }
}

// Sortowanie przez zamianę
void bubbleSort(int *S, int n) {
  for (int i = 1; i < n; i++) {
    bool zamiana = false;
    for (int j = n - 1; j >= i; j--) {
      if (S[j - 1] > S[j]) {
        swap(S[j - 1], S[j]);
        zamiana = true;
      }
    }
    if (!zamiana)
      break;
  }
}

// Podział
int split(int *S, int left, int right) {
  int index = right;
  swap(S[index], S[right]);
  int pivot = S[right];

  int i = left;

  for (int j = left; j < right; j++) {
    if (S[j] < pivot) {
      swap(S[j], S[i]);
      i++;
    }
  }
  swap(S[i], S[right]);
  return i;
}

// Sortowanie szybkie
void quickSort(int *S, int left, int right) {
  if (right > left) {
    int pivotIndex = split(S, left, right);
    quickSort(S, left, pivotIndex - 1);
    quickSort(S, pivotIndex + 1, right);
  }
}

// Sortowanie przez scalanie – łączenie
void merge(int *items, int left, int mid, int right) {
  int aux[right - left + 1];
  int i = left;
  int j = mid + 1;
  int k = 0;

  while (i <= mid && j <= right) {
    if (items[i] <= items[j]) {
      aux[k++] = items[i++];
    } else {
      aux[k++] = items[j++];
    }
  }

  while (i <= mid) {
    aux[k++] = items[i++];
  }

  while (j <= right) {
    aux[k++] = items[j++];
  }

  for (k = 0; k < right - left + 1; k++) {
    items[left + k] = aux[k];
  }
}

// Sortowanie przez scalanie
void mergeSort(int *S, int left, int right) {
  if (right > left) {
    int mid = (left + right) / 2;
    mergeSort(S, left, mid);
    mergeSort(S, mid + 1, right);
    merge(S, left, mid, right);
  }
}

// Sortowanie przez zliczanie
void cntSort(int *items, int n, int k) {

  int *o_items = new int[n];

  int *cnt = new int[k + 1]();

  for (int i = 0; i < n; i++) {
    cnt[items[i]] = cnt[items[i]] + 1;
  }

  for (int j = 1; j <= k; j++) {
    cnt[j] = cnt[j] + cnt[j - 1];
  }

  for (int i = n - 1; i >= 0; i--) {
    o_items[cnt[items[i]] - 1] = items[i];
    cnt[items[i]] = cnt[items[i]] - 1;
  }

  for (int i = 0; i < n; i++) {
    items[i] = o_items[i];
  }

  delete[] o_items;
  delete[] cnt;
}