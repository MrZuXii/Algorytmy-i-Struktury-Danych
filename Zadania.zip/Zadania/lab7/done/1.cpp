// Zadanie 1:

// Dla tablicy z haszowaniem przechowującej elementy z kluczem tekstowym
// (string) proszę zaimplementować wskazane w szablonie operacje. Proszę
// zastosować metodę próbkowanie liniowego do rozwiązania problemu kolizji.
// Proszę przetestować poprawność działania operacji. Testy powinny być
// zaprezentowane w sposób czytelny i jednoznaczny.

// Zadanie 2:

// Wykorzystując tablicę z haszowaniem z zadania 1 proszę wykonać eksperyment
// umożliwiający sprawdzenie:

// jak często pojawiając się kolizje, przy wstawianiu/wyszukiwaniu oraz

// ile prób wymaga wstawienie/wyszukanie pojedynczego klucza ,

// jak współczynnik zapełnienia tablicy wpływa na częstotliwość pojawiania się
// kolizji i liczbę prób przy wstawianiu klucza
//   int n = 40;      // początkowa pojemność tablicy z haszowaniem
//   string dane[40]; // tablica do przechowania danych do testowania, należy je
//   odczytać z pliku lub zainicjalizować nimi tablicę

#include <iostream>
#include <string>

using namespace std;

class HashTable {
private:
  string *t;
  int capacity;
  int size;

public:
  // konstruktor tworzący pustą tablicę o pojemności c
  HashTable(int c) : size(0), capacity(c) {
    t = new string[c];

    for (int i = 0; i < c; i++)
      t[i] = "";
  };

  bool empty() { return size == 0; };

  bool full() { return size == capacity; };

  // funkcja haszująca dla klucza s
  int hashFunction(string s) {
    int hash = 0;
    int prime = 31; // Stała liczba pierwsza
    int stringSize = s.size();

    for (int i = 0; i < stringSize; i++) {
      hash = (hash * prime + s[i]) % capacity;
    }
    return hash;
  };

  // wstawienie danych d z kluczem s (tutaj d=s)
  void insert(string d) {
    if (!full()) {
      int i = hashFunction(d);

      while (t[i] != "" && t[i] != "FREE")
        i = (i + 1) % capacity;

      t[i] = d;
      size++;
    }
  };

  // wstawienie danych d z kluczem s (zwraca liczbę prób przy wystąpieniu
  // kolizji - 0 jeśli kolizja nie wystąpiła)
  void insert1(string d) {
    if (!full()) {
      int i = hashFunction(d);
      int collision = 0;
      while (t[i] != "" && t[i] != "FREE") {
        i = (i + 1) % capacity;
        collision++;
      }

      t[i] = d;
      size++;
      cout << "Dodanie " << d << " liczba kolizji: " << collision << endl;
    }
  };

  // usuwa dane z kluczem s
  void del(string s) {
    if (empty()) {
      cout << "Error: tablica jest pusta";
      return;
    }
    int i = hashFunction(s);
    int start = i;

    while (t[i] != "") {
      if (t[i] == s) {
        t[i] = "FREE"; // Oznaczamy miejsce jako "wolne"
        size--;
        return;
      }
      i = (i + 1) % capacity; // Aktualizujemy indeks cyklicznie
      if (i == start)
        break;
    }
  }

  // wyszukuje i zwraca dane z s
  string search(string s) {
    if (empty()) {
      cout << "Error: tablica jest pusta";
      return "";
    }
    int i = hashFunction(s);
    int start = i;

    while (t[i] != "") {
      if (t[i] == s)
        return t[i];
      i = (i + 1) % capacity;

      if (i == start)
        break;
    }
    return "";
  };

  // wyszukuje s (zwraca liczbę prób przy wystąpieniu kolizji - 0 jeśli kolizja
  // nie wystąpiła)
  int search1(string s) {
    if (empty()) {
      cout << "Error: tablica jest pusta";
      return -1;
    }

    int i = hashFunction(s);
    int collision = 0;
    int start = i;

    while (t[i] != "") {
      if (t[i] == s) // Jeśli znaleźliśmy element
        return collision;

      i = (i + 1) %
          capacity; // Aktualizowanie indeksu, aby sprawdzić kolejny slot
      collision++;  // Zwiększamy liczbę kolizji

      if (i == start) // Jeśli wróciliśmy do miejsca początkowego, kończymy
                      // wyszukiwanie
        break;
    }
    return -1; // Jeśli nie znaleziono, zwracamy -1
  };

  // wypisuje tablicę (z numerami pól),
  // pozostawia puste dla wolnych pól
  friend ostream &operator<<(ostream &out, HashTable &ht) {
    for (int i = 0; i < ht.capacity; i++) {
      out << "Index: " << i << " : " << ht.t[i] << endl;
    }
    return out;
  };
};

int main(int argc, char **argv) {

  int n = 40; // początkowa pojemność tablicy z haszowaniem
  HashTable h(n);
  //   h.insert("Julia");
  //   h.insert("Zuzanna");
  //   h.insert("Amelia");

  //   cout << "Szukamy Zuzanna czy znalezliśmy?: " << h.search("Zuzanna") <<
  //   endl; cout << "Szukamy Amelia czy znalezliśmy?: " << h.search("Amelia")
  //   << endl; cout << "Usuwamy Amelia" << endl; h.del("Amelia"); cout <<
  //   "Szukamy Amelia czy znalezliśmy?: " << h.search("Amelia") << endl;

  h.insert("Julia");
  h.insert("Zuzanna");
  h.insert("Zofia");
  h.insert("Lena");
  h.insert("Maja");
  h.insert("Hanna");
  h.insert("Amelia");
  h.insert("Alicja");
  h.insert("Maria");
  h.insert("Aleksandra");
  h.insert("Oliwia");
  h.insert("Natalia");
  h.insert("Wiktoria");
  h.insert("Emilia");
  h.insert("Antonina");
  h.insert("Laura");
  h.insert("Pola");
  h.insert("Iga");
  h.insert("Anna");
  h.insert("Liliana");
  h.insert("Antoni");
  h.insert("Jakub");
  h.insert("Jan");
  h.insert("Szymon");
  h.insert("Franciszek");
  h.insert("Filip");
  h.insert("Aleksander");
  h.insert("Mikolaj");
  h.insert("Wojciech");
  h.insert("Kacper");
  h.insert("Adam");
  h.insert("Michal");
  h.insert("Marcel");
  h.insert("Stanislaw");
  h.insert("Wiktor");
  h.insert("Piotr");
  h.insert("Igor");
  h.insert("Leon");
  h.insert("Nikodem");
  h.insert("Mateusz");

  cout << "Szukamy Jan liczba kolizji: " << h.search1("Jan") << endl;
  cout << "Szukamy Nikodem liczba kolizji: " << h.search1("Nikodem") << endl;
  cout << "Szukamy Anna liczba kolizji: " << h.search1("Anna") << endl;
  h.search("xddd");
  cout << h;
  // cout << "insert(...)" << h.insert(); // po każdym wstawieniu/usunięciu
  // klucza należy// wyświetlić aktualny stan h

  return 0;
}

// Przykładowe dane do testowania:

// Julia
// Zuzanna
// Zofia
// Lena
// Maja
// Hanna
// Amelia
// Alicja
// Maria
// Aleksandra
// Oliwia
// Natalia
// Wiktoria
// Emilia
// Antonina
// Laura
// Pola
// Iga
// Anna
// Liliana
// Antoni
// Jakub
// Jan
// Szymon
// Franciszek
// Filip
// Aleksander
// Mikolaj
// Wojciech
// Kacper
// Adam
// Michal
// Marcel
// Stanislaw
// Wiktor
// Piotr
// Igor
// Leon
// Nikodem
// Mateusz

// h.insert1("Julia");
// h.insert1("Zuzanna");
// h.insert1("Zofia");
// h.insert1("Lena");
// h.insert1("Maja");
// h.insert1("Hanna");
// h.insert1("Amelia");
// h.insert1("Alicja");
// h.insert1("Maria");
// h.insert1("Aleksandra");
// h.insert1("Oliwia");
// h.insert1("Natalia");
// h.insert1("Wiktoria");
// h.insert1("Emilia");
// h.insert1("Antonina");
// h.insert1("Laura");
// h.insert1("Pola");
// h.insert1("Iga");
// h.insert1("Anna");
// h.insert1("Liliana");
// h.insert1("Antoni");
// h.insert1("Jakub");
// h.insert1("Jan");
// h.insert1("Szymon");
// h.insert1("Franciszek");
// h.insert1("Filip");
// h.insert1("Aleksander");
// h.insert1("Mikolaj");
// h.insert1("Wojciech");
// h.insert1("Kacper");
// h.insert1("Adam");
// h.insert1("Michal");
// h.insert1("Marcel");
// h.insert1("Stanislaw");
// h.insert1("Wiktor");
// h.insert1("Piotr");
// h.insert1("Igor");
// h.insert1("Leon");
// h.insert1("Nikodem");
// h.insert1("Mateusz");