#include <iostream>

using namespace std;
// Drzewo binarne: kopiec binarny  i jego zastosowanie w realizacji kolejki
// priorytetowej

// Zadanie 1:

// Dla kopca binarnego proszę zaimplementować wskazane w szablonie operacje dla
// kopca typu max lub min. Proszę przetestować poprawność ich działania – testy
// powinny być opracowane w taki sposób, aby weryfikowały działanie operacji we
// wszystkich możliwych do zaistnienia przypadkach. Testy powinny być
// zaprezentowane w sposób czytelny i jednoznaczny.

class Heap {
private:
  int *kopiec;
  int capacity;
  int size;

public:
  // tworzy pusty kopiec o pojemności c
  Heap(int c) : capacity(c), size(0) { kopiec = new int[c]; };

  bool empty() { return size == 0; };

  bool full() { return size == capacity; };

  // zwraca pozycję lewego syna
  int getLeft(int i) {
    if ((i * 2) + 1 < size) {
      return (i * 2) + 1;
    } else {
      return -1;
    }
  };

  // zwraca pozycję prawego syna
  int getRight(int i) {
    if ((i * 2) + 2 < size) {
      return (i * 2) + 2;
    } else {
      return -1;
    }
  };

  // zwraca pozycję ojca
  int getParent(int i) {
    if (i != 0) {
      return (i - 1) / 2;
    } else {
      return -1;
    }
  };

  // zwraca rozmiar kopca
  int getSize() { return size; };

  // ustawia rozmiar kopca na s
  void setSize(int s) { size = s; };

  // zwraca wartość z pozycji i
  int getValue(int i) {
    if (empty()) {
      cout << "Error Kopiec jest pusty";
      return -1;
    }
    return kopiec[i];
  };

  // ustawia wartość x na pozycji i
  void setValue(int i, int x) {
    kopiec[i] = x;
    bottomUp(i);
    topDown(i);
  };

  // przywraca własność kopca metodą wynurzania
  void bottomUp(int i) {
    if (i > 0) {
      int p = getParent(i);
      if (kopiec[i] > kopiec[p]) {
        swap(kopiec[i], kopiec[p]);
        bottomUp(p);
      }
    }
  };

  // przywraca własność kopca metodą zatapiania
  void topDown(int i) {
    int l = getLeft(i);
    int r = getRight(i);

    int g = i;

    if (l != -1 && kopiec[l] > kopiec[i])
      g = l;
    if (r != -1 && kopiec[r] > kopiec[g])
      g = r;
    if (g != i) {
      swap(kopiec[i], kopiec[g]);
      topDown(g);
    }
  };
  // wstawia element z wartością x (tutaj wartość jest jednocześnie priorytetem)
  void insert(int x) {
    if (full()) {
      cout << "Error kopiec jest pełny";
      return;
    }
    kopiec[size] = x;
    bottomUp(size);
    size++;
  };

  // usuwa element z "maksymalną" wartością priorytetu
  void deleteP() {
    if (empty()) {
      cout << "Error: kopiec jest pusty";
      return;
    }
    size--;
    swap(kopiec[0], kopiec[size]);
    topDown(0);
  };

  // usuwa element na pozycji i
  void del(int i) {
    if (empty()) {
      cout << "Error: kopiec jest pusty";
      return;
    }
    size--;
    swap(kopiec[i], kopiec[size]);
    topDown(i);
    bottomUp(i);
  };

  friend std::ostream &operator<<(std::ostream &out, Heap &h) {
    if (h.empty()) {
      out << "Kopiec pusty";
      return out;
    }
    for (int i = 0; i < h.size; i++) {
      out << h.getValue(i) << " ";
    }
    out << endl;
    return out;
  };
};

int main() {
  Heap h(15);
  h.insert(12);
  h.insert(9);
  h.insert(13);
  h.insert(15);
  h.insert(14);
  h.insert(2);
  h.insert(4);
  cout << h;
  return 0;
};