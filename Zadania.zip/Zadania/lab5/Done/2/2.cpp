#include <cstdlib>
#include <ctime>
#include <iostream>
#include <limits>

// Dla grafu ważonego (skierowanego lub nieskierowanego) reprezentowanego w
// postaci macierzy sąsiedztwa proszę zaimplementować wskazane w szablonie
// operacje. Proszę przetestować ich poprawność.

using namespace std;

struct weightedEdge {
  int s;
  int t;
  double w; // waga krawędzi
};

class WeightedGraph {
private:
  double **adjWeightMatrix;
  int n; // liczba węzłów
  bool directed;

public:
  // tworzy graf w oparciu o podaną listę krawędzi z wagami
  WeightedGraph(int n, int m, weightedEdge edges[], bool directed)
      : n(n), directed(directed) {
    adjWeightMatrix = new double *[n];

    for (int i = 0; i < n; i++) {
      adjWeightMatrix[i] = new double[n];

      for (int j = 0; j < n; j++) {

        adjWeightMatrix[i][j] =
            (i == j) ? 0 : numeric_limits<double>::infinity();
      }
    }

    for (int i = 0; i < m; i++) {
      int s = edges[i].s;
      int t = edges[i].t;
      double w = edges[i].w;

      adjWeightMatrix[s][t] = w;

      if (!directed) {
        adjWeightMatrix[t][s] = w;
      }
    }
  };

  // tworzy losowy graf
  WeightedGraph(int n, int m, bool directed) : n(n), directed(directed) {
    adjWeightMatrix = new double *[n];

    for (int i = 0; i < n; i++) {
      adjWeightMatrix[i] = new double[n];

      for (int j = 0; j < n; j++) {
        adjWeightMatrix[i][j] =
            (i == j) ? 0 : numeric_limits<double>::infinity();
      }
    }

    srand(time(0));
    int addedEdges = 0;

    while (addedEdges < m) {
      int s = rand() % n;
      int t = rand() % n;

      if (s != t &&
          adjWeightMatrix[s][t] == numeric_limits<double>::infinity()) {

        double w = (rand() % 11) +
                   (rand() % 10) / 10.0; // Losowa waga w przedziale 0.0-10.9

        adjWeightMatrix[s][t] = w;

        if (!directed) {
          adjWeightMatrix[t][s] = w;
        }
        addedEdges++;
      }
    }
  };

  friend ostream &operator<<(ostream &out, WeightedGraph &g) {
    double **adjWeightMatrix = g.adjWeightMatrix;
    int n = g.n;
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        if (adjWeightMatrix[i][j] == numeric_limits<double>::infinity()) {
          out << "INF\t";
        } else {
          out << adjWeightMatrix[i][j] << "\t";
        }
      }
      out << endl;
    }
    return out;
  };

  ~WeightedGraph() {
    for (int i = 0; i < n; i++) {
      delete[] adjWeightMatrix[i];
    }
    delete[] adjWeightMatrix;
  };
};

int main() {
  int n = 5, m = 12;
  weightedEdge directedGraph[] = {
      {0, 1, 5}, // Krawędź z wierzchołka 0 do 1 z wagą 5
      {0, 2, 3}, // Krawędź z wierzchołka 0 do 2 z wagą 3
      {0, 3, 8}, // Krawędź z wierzchołka 0 do 3 z wagą 8
      {1, 2, 2}, // Krawędź z wierzchołka 1 do 2 z wagą 2
      {1, 4, 7}, // Krawędź z wierzchołka 1 do 4 z wagą 7
      {2, 0, 6}, // Krawędź z wierzchołka 2 do 0 z wagą 6
      {2, 3, 4}, // Krawędź z wierzchołka 2 do 3 z wagą 4
      {2, 4, 9}, // Krawędź z wierzchołka 2 do 4 z wagą 9
      {3, 1, 1}, // Krawędź z wierzchołka 3 do 1 z wagą 1
      {3, 4, 5}, // Krawędź z wierzchołka 3 do 4 z wagą 5
      {4, 0, 7}, // Krawędź z wierzchołka 4 do 0 z wagą 7
      {4, 2, 8}  // Krawędź z wierzchołka 4 do 2 z wagą 8
  };

  // WeightedGraph g(n, m, directedGraph, true);
  WeightedGraph g(n, m, true);
  cout << g;
  return 0;
}