#include <iostream>

using namespace std;

// Dla grafu ważonego (skierowanego lub nieskierowanego) reprezentowanego w
// postaci macierzy sąsiedztwa proszę zaimplementować algorytm Dijkstry
// znajdywania najkrótszej ścieżki z wybranego węzła s do pozostałych węzłów.
// Algorytm powinien zwracać, dla każdego węzła jego odległość od s oraz jego
// poprzednika na ścieżce od s. Proszę przetestować poprawność algorytmu dla
// różnych węzłów źródłowych.

// Zadanie 2:

// Do klasy z zadania 1 proszę dodać i przetestować metodę void
// shortestPath(int s, int t, int* parent) wyświetlającą węzły należące do
// najkrótszej ścieżki od węzła s do węzła t (na potrzeby testowania należy
// ją wywołać na końcu, w metodzie Dijkstra).

// Zadanie 3:

// Do programu z zadania 3 proszę dodać i przetestować algorytm
// Warshalla-Floyda. W wyniku należy wyświetlić długości najkrótszych ścieżek
// pomiędzy wszystkimi parami węzłów.
// void Warshall-Floyd();
// 19

struct weightedEdge {
  int s;
  int t;
  double w; // waga krawędzi
};

class WeightedGraph {
private:
  double **adjWeightMatrix;
  int n; // liczba węzłów
  bool directed;

public:
  // tworzy graf w oparciu o podaną listę krawędzi z wagami
  WeightedGraph(int n, int m, weightedEdge edges[], bool directed);

  WeightedGraph(int n, int m, bool directed); // tworzy losowy graf

  void Dijkstra(int s);

  friend ostream &operator<<(ostream &out, WeightedGraph &g);

  ~WeightedGraph();
};

int main() {
  int n = 6, m = 15;
  // weightedEdge directedWeightedGraph[]={.......};
  // WeightedGraph h(n,m,directedWeightedGraph,true);
  // h.dijkstra(0);
  return 0;
}