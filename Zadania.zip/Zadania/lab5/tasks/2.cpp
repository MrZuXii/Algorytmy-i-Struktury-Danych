#include <iostream>

// Dla grafu ważonego (skierowanego lub nieskierowanego) reprezentowanego w
// postaci macierzy sąsiedztwa proszę zaimplementować wskazane w szablonie
// operacje. Proszę przetestować ich poprawność.

using namespace std;

struct weightedEdge {
  int s;
  int t;
  double w; // waga krawędzi
};

class WeightedGraph {
private:
  double **adjWeightMatrix;
  int n; // liczba węzłów
  bool directed;

public:
  // tworzy graf w oparciu o podaną listę krawędzi z wagami
  WeightedGraph(int n, int m, weightedEdge edges[], bool directed){};

  // tworzy losowy graf
  WeightedGraph(int n, int m, bool directed){};
  friend ostream &operator<<(ostream &out, WeightedGraph &g) {};
  ~WeightedGraph(){};
};

int main() {
  cout << "Hello World";
  return 0;
}